package app.ladelog

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Läuft im Hintergrund und schreibt bei jeder Änderung (und mindestens jede Minute) eine Messung. */
class LogService : Service() {

    companion object {
        const val ACTION_TICK = "app.ladelog.TICK"
        private const val CHANNEL = "ladelog"
        private const val NOTIF_ID = 1
        private const val HEARTBEAT = 5 * 60_000L

        fun start(c: Context): Boolean {
            return try {
                c.startForegroundService(Intent(c, LogService::class.java))
                true
            } catch (e: Exception) {
                Store(c).log("Dienst-Start nicht erlaubt: " + e.message)
                false
            }
        }

        fun stop(c: Context) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pending(c))
            c.stopService(Intent(c, LogService::class.java))
        }

        private fun pending(c: Context): PendingIntent =
            PendingIntent.getForegroundService(
                c, 1,
                Intent(c, LogService::class.java).setAction(ACTION_TICK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        private fun scheduleHeartbeat(c: Context) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + HEARTBEAT,
                HEARTBEAT,
                pending(c)
            )
        }
    }

    private var last: Sample? = null

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            sample(false)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground(Reader.now(this))
        last = LogStore.lastSample(this)
        val f = IntentFilter()
        f.addAction(Intent.ACTION_BATTERY_CHANGED)
        f.addAction(Intent.ACTION_POWER_CONNECTED)
        f.addAction(Intent.ACTION_POWER_DISCONNECTED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(rx, f)
        }
        Store(this).log("Aufzeichnung gestartet")
        LogStore.prune(this)
        scheduleHeartbeat(this)
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(rx)
        } catch (e: Exception) {
        }
        Store(this).log("Aufzeichnung beendet")
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        sample(true)
        return START_STICKY
    }

    private fun sample(force: Boolean) {
        val s = Reader.now(this)
        if (s.level < 0) return
        val l = last
        val due = l == null || force || s.level != l.level || s.status != l.status ||
            s.plugged != l.plugged || s.t - l.t >= 60_000L
        if (due) {
            LogStore.append(this, s)
            last = s
        }
        goForeground(s)
    }

    private fun goForeground(s: Sample) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Ladelog", NotificationManager.IMPORTANCE_LOW)
        )
        val state = when (s.cat) {
            1 -> "lädt"
            2 -> "am Kabel, lädt nicht"
            else -> "nicht am Kabel"
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("Ladelog läuft")
            .setContentText(s.level.toString() + " % · " + state)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            Store(this).log("startForeground fehlgeschlagen: " + e.message)
        }
    }
}
