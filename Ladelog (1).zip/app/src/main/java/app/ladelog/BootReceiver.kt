package app.ladelog

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Nach einem Neustart die Aufzeichnung wieder starten. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Store(context).enabled) LogService.start(context)
    }
}
