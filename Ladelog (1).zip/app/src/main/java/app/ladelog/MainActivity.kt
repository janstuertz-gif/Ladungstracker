package app.ladelog

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Zeigt, wann das Handy lädt: Diagramm, Test-Auswertung und Liste der Phasen. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var rangeLabel: TextView
    private lateinit var chart: ChartView
    private lateinit var summaryView: TextView
    private lateinit var phasesView: TextView
    private lateinit var logView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 5000L)
        }
    }

    // ------------------------------------------------------------ Hilfsfunktionen

    private fun dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    private fun copy(t: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ladelog", t))
        toast("Kopiert")
    }

    private fun label(parent: LinearLayout, s: String, size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        t.setPadding(0, dp(12), 0, dp(4))
        parent.addView(t)
        return t
    }

    private fun button(parent: LinearLayout, s: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.setOnClickListener { action() }
        parent.addView(
            b,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        return b
    }

    private fun rangeButton(parent: LinearLayout, s: String, hours: Int) {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.setOnClickListener {
            Store(this).rangeH = hours
            refresh()
        }
        parent.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    // ------------------------------------------------------------------ Aufbau

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(96))
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        label(root, "Ladelog", 24f, true)
        status = label(root, "", 14f, false)
        toggle = button(root, "Aufzeichnung") {
            val st = Store(this)
            if (st.enabled) {
                st.enabled = false
                LogService.stop(this)
            } else {
                st.enabled = true
                LogService.start(this)
            }
            refresh()
        }
        button(root, "Akku-Optimierung für diese App ausschalten") {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        label(
            root,
            "Test „Intelligentes Laden“: 1) Es in den Handy-Einstellungen einschalten. " +
                "2) Handy am Kabel auf 100 % laden und dranlassen (am besten über Nacht). " +
                "3) Hier nachsehen. Unter „Test“ steht, bei welchem Stand das Laden stoppt und wieder startet. " +
                "Tipp: Autostart/Hintergrund für diese App in den Handy-Einstellungen erlauben, " +
                "sonst beendet das Handy die Aufzeichnung.",
            12f, false
        )

        rangeLabel = label(root, "Zeitraum", 18f, true)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        root.addView(row)
        rangeButton(row, "6 h", 6)
        rangeButton(row, "24 h", 24)
        rangeButton(row, "3 Tage", 72)
        rangeButton(row, "7 Tage", 168)

        label(root, "🟩 lädt   🟧 am Kabel, lädt nicht   ⬜ nicht am Kabel   🟥 keine Daten", 12f, false)
        chart = ChartView(this)
        root.addView(
            chart,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260))
        )

        label(root, "Test: Stopp und Wiederbeginn", 18f, true)
        summaryView = label(root, "", 14f, false)

        label(root, "Phasen (neueste zuerst)", 18f, true)
        phasesView = label(root, "", 13f, false)

        button(root, "Auswertung kopieren") { copy(report()) }
        button(root, "Rohdaten (24 h) kopieren") { copy(raw24()) }
        button(root, "Alle Daten löschen") {
            AlertDialog.Builder(this)
                .setTitle("Alle Daten löschen?")
                .setPositiveButton("Löschen") { _, _ ->
                    LogStore.clear(this)
                    refresh()
                }
                .setNegativeButton("Abbrechen", null)
                .show()
        }

        label(root, "Protokoll", 18f, true)
        logView = label(root, "", 12f, false)
        logView.setTextIsSelectable(true)
    }

    override fun onResume() {
        super.onResume()
        if (Store(this).enabled) LogService.start(this)
        ticker.run()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    // ----------------------------------------------------------------- Anzeige

    private fun phaseText(p: Phase): String {
        val head = when (p.cat) {
            1 -> "🟩 Lädt"
            2 -> "🟧 Am Kabel, lädt nicht (" + statusName(p.status) + ")"
            3 -> "🟥 Keine Daten"
            else -> "⬜ Nicht am Kabel"
        }
        val time = fmtT(p.start, true) + " – " + fmtT(p.end, true) + " (" + fmtDur(p.end - p.start) + ")"
        if (p.cat == 3) return head + "\n   " + time
        val lv = p.lv0.toString() + " % → " + p.lv1 + " %"
        val ma = if (p.cat == 1 || p.cat == 2) " · Ø " + p.avgMa + " mA" else ""
        return head + "\n   " + time + "\n   " + lv + ma
    }

    private fun report(): String {
        val now = System.currentTimeMillis()
        val st = Store(this)
        val from = now - st.rangeH * 3_600_000L
        val ph = buildPhases(LogStore.readAll(this).filter { it.t >= from }, now)
        val sum = summary(ph)
        val sb = StringBuilder()
        sb.append("Ladelog-Auswertung, letzte ").append(st.rangeH).append(" h\n\n")
        sb.append(if (sum.isEmpty()) "Keine Pause am Kabel aufgezeichnet.\n" else sum.joinToString("\n") + "\n")
        sb.append("\nPhasen (neueste zuerst):\n")
        for (p in ph.asReversed()) sb.append(phaseText(p)).append("\n")
        return sb.toString()
    }

    private fun raw24(): String {
        val from = System.currentTimeMillis() - 24 * 3_600_000L
        val sb = StringBuilder("zeit_ms,prozent,status,kabel,strom_uA,temp_zehntelgrad,spannung_mV\n")
        for (s in LogStore.readAll(this)) {
            if (s.t >= from) {
                sb.append(s.t).append(',').append(s.level).append(',').append(s.status).append(',')
                    .append(s.plugged).append(',').append(s.cur).append(',').append(s.temp).append(',')
                    .append(s.mv).append('\n')
            }
        }
        return sb.toString()
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        val st = Store(this)
        val s = Reader.now(this)
        val all = LogStore.readAll(this)
        val from = now - st.rangeH * 3_600_000L
        val inRange = all.filter { it.t >= from }

        val sb = StringBuilder()
        sb.append("Jetzt: ").append(s.level).append(" % · ").append(statusName(s.status))
            .append(" · ").append(plugName(s.plugged)).append('\n')
        sb.append("Strom: ").append(s.mA).append(" mA · ")
            .append(String.format(Locale.GERMANY, "%.1f", s.temp / 10.0)).append(" °C · ")
            .append(String.format(Locale.GERMANY, "%.2f", s.mv / 1000.0)).append(" V\n")
        sb.append("Aufzeichnung: ").append(if (st.enabled) "läuft" else "aus")
            .append(" · ").append(all.size).append(" Messpunkte")
        if (all.isNotEmpty()) sb.append(" seit ").append(fmtT(all[0].t, true))
        status.text = sb.toString()

        toggle.text = if (st.enabled) "Aufzeichnung stoppen" else "Aufzeichnung starten"
        rangeLabel.text = "Zeitraum: letzte " + st.rangeH + " h"

        chart.samples = inRange
        chart.t0 = from
        chart.t1 = now
        chart.invalidate()

        val ph = buildPhases(inRange, now)
        val sum = summary(ph)
        summaryView.text =
            if (sum.isEmpty()) "Noch keine Pause am Kabel aufgezeichnet." else sum.takeLast(12).joinToString("\n")
        phasesView.text =
            if (ph.isEmpty()) "–" else ph.asReversed().take(40).joinToString("\n\n") { phaseText(it) }
        val lg = st.logText()
        logView.text = if (lg.isEmpty()) "(leer)" else lg
    }
}
