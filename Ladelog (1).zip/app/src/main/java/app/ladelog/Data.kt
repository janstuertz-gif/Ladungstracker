package app.ladelog

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Mehr als 20 Minuten ohne Messung = Lücke (die Aufzeichnung lief nicht). */
const val GAP_MS = 20 * 60_000L

/** Eine Messung. cur = Strom in µA (Betrag/Vorzeichen je nach Handy), temp in 0,1 °C, mv in mV. */
data class Sample(
    val t: Long,
    val level: Int,
    val status: Int,
    val plugged: Int,
    val cur: Int,
    val temp: Int,
    val mv: Int
) {
    /** 0 = nicht am Kabel, 1 = lädt, 2 = am Kabel, lädt nicht */
    val cat: Int
        get() = if (plugged == 0) 0 else if (status == BatteryManager.BATTERY_STATUS_CHARGING) 1 else 2

    /** Strom in mA (Betrag; Android liefert µA) */
    val mA: Int
        get() = Math.abs(cur / 1000)
}

class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("ladelog", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    var rangeH: Int
        get() = sp.getInt("rangeH", 24)
        set(v) { sp.edit().putInt("rangeH", v).apply() }

    fun log(msg: String) {
        val line = SimpleDateFormat("dd.MM. HH:mm:ss", Locale.GERMANY).format(Date()) + "  " + msg
        val old = sp.getString("log", "") ?: ""
        val lines = old.split("\n").filter { it.isNotEmpty() } + line
        sp.edit().putString("log", lines.takeLast(40).joinToString("\n")).apply()
    }

    fun logText(): String = sp.getString("log", "") ?: ""
}

/** Die Messdaten liegen als einfache CSV-Datei in der App. */
object LogStore {
    private var cache: List<Sample> = emptyList()
    private var cacheLen = -1L

    private fun file(c: Context) = File(c.filesDir, "log.csv")

    fun parse(line: String): Sample? {
        val p = line.trim().split(",")
        if (p.size < 7) return null
        return try {
            Sample(
                p[0].toLong(), p[1].toInt(), p[2].toInt(), p[3].toInt(),
                p[4].toInt(), p[5].toInt(), p[6].toInt()
            )
        } catch (e: Exception) {
            null
        }
    }

    fun append(c: Context, s: Sample) {
        val line = s.t.toString() + "," + s.level + "," + s.status + "," + s.plugged + "," +
            s.cur + "," + s.temp + "," + s.mv + "\n"
        try {
            FileOutputStream(file(c), true).use { it.write(line.toByteArray()) }
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun readAll(c: Context): List<Sample> {
        val f = file(c)
        if (!f.exists()) {
            cache = emptyList()
            cacheLen = -1L
            return cache
        }
        val len = f.length()
        if (len == cacheLen) return cache
        val out = ArrayList<Sample>()
        try {
            f.forEachLine { line ->
                val s = parse(line)
                if (s != null) out.add(s)
            }
        } catch (e: Exception) {
        }
        cache = out
        cacheLen = len
        return out
    }

    /** Letzte Messung, ohne die ganze Datei zu lesen. */
    fun lastSample(c: Context): Sample? {
        val f = file(c)
        if (!f.exists() || f.length() == 0L) return null
        return try {
            RandomAccessFile(f, "r").use { raf ->
                val len = raf.length()
                val n = minOf(len, 200L).toInt()
                val buf = ByteArray(n)
                raf.seek(len - n)
                raf.readFully(buf)
                parse(String(buf).trim().split("\n").last())
            }
        } catch (e: Exception) {
            null
        }
    }

    fun prune(c: Context) {
        val f = file(c)
        if (!f.exists() || f.length() < 2_000_000L) return
        try {
            val lines = f.readLines()
            if (lines.size > 30000) f.writeText(lines.takeLast(30000).joinToString("\n") + "\n")
        } catch (e: Exception) {
        }
        cacheLen = -1L
    }

    fun clear(c: Context) {
        file(c).delete()
        cache = emptyList()
        cacheLen = -1L
    }
}

object Reader {
    fun now(c: Context): Sample {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val temp = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        var cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (cur == Int.MIN_VALUE) cur = 0
        return Sample(System.currentTimeMillis(), pct, status, plugged, cur, temp, mv)
    }
}

/** Ein zusammenhängender Abschnitt: cat 0 = nicht am Kabel, 1 = lädt, 2 = am Kabel/lädt nicht, 3 = keine Daten */
data class Phase(
    val cat: Int,
    val start: Long,
    val end: Long,
    val lv0: Int,
    val lv1: Int,
    val avgMa: Int,
    val status: Int
)

fun buildPhases(s: List<Sample>, now: Long): List<Phase> {
    val out = ArrayList<Phase>()
    var i = 0
    while (i < s.size) {
        val c = s[i].cat
        var j = i
        while (j + 1 < s.size && s[j + 1].cat == c && s[j + 1].t - s[j].t <= GAP_MS) j++
        var sum = 0L
        for (k in i..j) sum += s[k].mA
        val avg = (sum / (j - i + 1)).toInt()
        val contiguous = j + 1 < s.size && s[j + 1].t - s[j].t <= GAP_MS
        val end = if (contiguous) s[j + 1].t else if (j + 1 >= s.size && now - s[j].t <= GAP_MS) now else s[j].t
        out.add(Phase(c, s[i].t, end, s[i].level, s[j].level, avg, s[j].status))
        if (j + 1 < s.size && !contiguous) {
            out.add(Phase(3, s[j].t, s[j + 1].t, s[j].level, s[j + 1].level, 0, 0))
        }
        i = j + 1
    }
    return out
}

/** Zeilen für den Test: wann das Laden stoppt und bei welchem Stand es weitergeht. */
fun summary(ph: List<Phase>): List<String> {
    val out = ArrayList<String>()
    for (k in 0 until ph.size - 1) {
        val a = ph[k]
        val b = ph[k + 1]
        if (a.cat == 1 && b.cat == 2) {
            out.add(fmtT(b.start, true) + "  Laden gestoppt bei " + b.lv0 + " %")
        }
        if (a.cat == 2 && b.cat == 1) {
            out.add(
                fmtT(b.start, true) + "  Laden wieder gestartet bei " + b.lv0 +
                    " % (nach " + fmtDur(a.end - a.start) + " Pause)"
            )
        }
    }
    return out
}

fun fmtT(t: Long, date: Boolean): String =
    SimpleDateFormat(if (date) "dd.MM. HH:mm" else "HH:mm", Locale.GERMANY).format(Date(t))

fun fmtDur(ms: Long): String {
    val m = ms / 60_000L
    return if (m >= 60) {
        (m / 60).toString() + " h " + (m % 60).toString() + " min"
    } else if (m >= 1) {
        m.toString() + " min"
    } else {
        (ms / 1000L).toString() + " s"
    }
}

fun statusName(s: Int): String = when (s) {
    BatteryManager.BATTERY_STATUS_CHARGING -> "lädt"
    BatteryManager.BATTERY_STATUS_DISCHARGING -> "entlädt"
    BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "lädt nicht"
    BatteryManager.BATTERY_STATUS_FULL -> "voll"
    else -> "unbekannt"
}

fun plugName(p: Int): String = when (p) {
    0 -> "nicht am Kabel"
    BatteryManager.BATTERY_PLUGGED_AC -> "Netzteil"
    BatteryManager.BATTERY_PLUGGED_USB -> "USB"
    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "kabellos"
    else -> "Dock"
}
