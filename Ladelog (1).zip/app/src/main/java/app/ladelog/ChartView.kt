package app.ladelog

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Akkustand als Linie, dahinter farbig: grün = lädt, orange = am Kabel aber lädt nicht, rot = keine Daten. */
class ChartView(ctx: Context) : View(ctx) {

    var samples: List<Sample> = emptyList()
    var t0: Long = 0L
    var t1: Long = 1L

    private val d = ctx.resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val band = Paint()
    private val grid = Paint()
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        line.color = Color.rgb(21, 101, 192)
        line.style = Paint.Style.STROKE
        line.strokeWidth = 2.5f * d
        grid.color = Color.argb(50, 0, 0, 0)
        grid.strokeWidth = 1f
        txt.color = Color.argb(170, 0, 0, 0)
        txt.textSize = 11f * d
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val l = 38f * d
        val r = w - 8f * d
        val tp = 8f * d
        val bt = h - 20f * d
        val span = (t1 - t0).coerceAtLeast(1L).toFloat()

        var mn = 100
        for (s in samples) {
            if (s.level in 0 until mn) mn = s.level
        }
        val y0 = ((mn / 10) * 10 - 10).coerceIn(0, 90)
        val range = (100 - y0).toFloat()

        fun xAt(t: Long): Float = l + (t - t0).toFloat() / span * (r - l)
        fun yAt(p: Int): Float = bt - (p - y0).toFloat() / range * (bt - tp)

        // Raster und Prozent-Beschriftung
        val step = if (range <= 30f) 5 else 10
        var p = y0
        while (p <= 100) {
            val y = yAt(p)
            canvas.drawLine(l, y, r, y, grid)
            canvas.drawText(p.toString() + "%", 2f * d, y + 4f * d, txt)
            p += step
        }

        val n = samples.size
        if (n == 0) {
            canvas.drawText("Noch keine Daten in diesem Zeitraum", l + 10f * d, (tp + bt) / 2, txt)
        } else {
            // Lücke am linken Rand
            if (samples[0].t - t0 > GAP_MS) {
                band.color = Color.argb(45, 244, 67, 54)
                canvas.drawRect(xAt(t0), tp, xAt(samples[0].t), bt, band)
            }
            // Farbflächen
            for (i in 0 until n) {
                val s = samples[i]
                val nt = if (i + 1 < n) samples[i + 1].t else t1
                val a = maxOf(s.t, t0)
                val b = minOf(nt, t1)
                if (b <= a) continue
                if (nt - s.t > GAP_MS) {
                    band.color = Color.argb(45, 244, 67, 54)
                    canvas.drawRect(xAt(a), tp, xAt(b), bt, band)
                } else if (s.cat == 1) {
                    band.color = Color.argb(75, 0, 200, 83)
                    canvas.drawRect(xAt(a), tp, xAt(b), bt, band)
                } else if (s.cat == 2) {
                    band.color = Color.argb(85, 255, 152, 0)
                    canvas.drawRect(xAt(a), tp, xAt(b), bt, band)
                }
            }
            // Akkulinie
            path.reset()
            var pen = false
            for (i in 0 until n) {
                val s = samples[i]
                if (s.level < 0 || s.t < t0) continue
                val x = xAt(s.t)
                val y = yAt(s.level.coerceIn(y0, 100))
                val broken = i > 0 && s.t - samples[i - 1].t > GAP_MS
                if (!pen || broken) path.moveTo(x, y) else path.lineTo(x, y)
                pen = true
            }
            val lastS = samples[n - 1]
            if (pen && lastS.level >= 0 && t1 - lastS.t <= GAP_MS) {
                path.lineTo(xAt(t1), yAt(lastS.level.coerceIn(y0, 100)))
            }
            canvas.drawPath(path, line)
        }

        // Zeitbeschriftung
        val withDate = (t1 - t0) > 24 * 3_600_000L
        for (k in 0..3) {
            val t = t0 + (t1 - t0) * k / 3
            val label = fmtT(t, withDate)
            val tw = txt.measureText(label)
            val x = (xAt(t) - tw / 2).coerceIn(0f, w - tw)
            canvas.drawText(label, x, h - 4f * d, txt)
        }
    }
}
